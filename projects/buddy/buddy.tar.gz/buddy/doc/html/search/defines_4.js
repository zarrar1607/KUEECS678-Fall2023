var searchData=
[
  ['max_5forder_136',['MAX_ORDER',['../buddy_8c.html#ab08dffec08ac450d78d4c062b571939e',1,'buddy.c']]],
  ['min_5forder_137',['MIN_ORDER',['../buddy_8c.html#a23bae2b7cd4008c90256be146e21cccf',1,'buddy.c']]]
];
