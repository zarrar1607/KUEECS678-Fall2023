var searchData=
[
  ['var_5fmap_66',['var_map',['../simulator_8c.html#aac0a9bd81116672e0737054410aa7dc0',1,'simulator.c']]],
  ['var_5ft_67',['var_t',['../structvar__t.html',1,'var_t'],['../simulator_8c.html#a9375b18625d2a9abb6a2a47672ad25a3',1,'var_t():&#160;simulator.c']]]
];
