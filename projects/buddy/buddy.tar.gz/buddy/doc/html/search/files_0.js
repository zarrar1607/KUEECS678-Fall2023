var searchData=
[
  ['buddy_2ec_72',['buddy.c',['../buddy_8c.html',1,'']]],
  ['buddy_2eh_73',['buddy.h',['../buddy_8h.html',1,'']]]
];
