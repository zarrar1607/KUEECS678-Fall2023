var searchData=
[
  ['badinput_4',['BADINPUT',['../simulator_8c.html#af9bff8ff1154a04a899276af806b8586a7319e63f337beebb4630f30672560c28',1,'simulator.c']]],
  ['buddy_2ec_5',['buddy.c',['../buddy_8c.html',1,'']]],
  ['buddy_2eh_6',['buddy.h',['../buddy_8h.html',1,'']]],
  ['buddy_5faddr_7',['BUDDY_ADDR',['../buddy_8c.html#aae7263f0e40a1e0dfefa6f53652a4a05',1,'buddy.c']]],
  ['buddy_5falloc_8',['buddy_alloc',['../buddy_8c.html#a8197baf99e89c859b5326a1d455680fd',1,'buddy_alloc(int size):&#160;buddy.c'],['../buddy_8h.html#a8197baf99e89c859b5326a1d455680fd',1,'buddy_alloc(int size):&#160;buddy.c']]],
  ['buddy_5fdump_9',['buddy_dump',['../buddy_8c.html#aa16d99b90dd0a6b9d7e3db0573620c21',1,'buddy_dump():&#160;buddy.c'],['../buddy_8h.html#aa16d99b90dd0a6b9d7e3db0573620c21',1,'buddy_dump():&#160;buddy.c']]],
  ['buddy_5ffree_10',['buddy_free',['../buddy_8c.html#a961ef8a2fd9df43d50945100f172b97a',1,'buddy_free(void *addr):&#160;buddy.c'],['../buddy_8h.html#a961ef8a2fd9df43d50945100f172b97a',1,'buddy_free(void *addr):&#160;buddy.c']]],
  ['buddy_5finit_11',['buddy_init',['../buddy_8c.html#a6674e7c974485f8a5dd8874e9eb125f3',1,'buddy_init():&#160;buddy.c'],['../buddy_8h.html#a6674e7c974485f8a5dd8874e9eb125f3',1,'buddy_init():&#160;buddy.c']]]
];
