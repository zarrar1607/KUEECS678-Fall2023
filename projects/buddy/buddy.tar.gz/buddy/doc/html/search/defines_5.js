var searchData=
[
  ['page_5fsize_138',['PAGE_SIZE',['../buddy_8c.html#a7d467c1d283fdfa1f2081ba1e0d01b6e',1,'buddy.c']]],
  ['page_5fto_5faddr_139',['PAGE_TO_ADDR',['../buddy_8c.html#a7c13b46aacf7af9976a7f058076c81a3',1,'buddy.c']]],
  ['pdebug_140',['PDEBUG',['../buddy_8c.html#a9077500d1488a75e4eec5eeb1131655e',1,'buddy.c']]]
];
